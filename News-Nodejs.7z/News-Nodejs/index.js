const express = require ('express');
const app = express() ;


// cấu hình body-parser
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extend:false}));
app.use(bodyParser.json())

//Routers
required('./src/routers/News.Router')(app);
required('./src/routers/Comment.Router')(app);
required('./src/routers/Topic.Router')(app);
required('./src/routers/Reply_comment.Router')(app);

//listen on port 3000 
app.listen(5000,function () {
    console.log("Server listenning on http://localhost:5000");
})