module.exports= function(router){
    var NewsController =require('../Controllers/News.Controller');

router.get('/News/List',NewsController.get_list_news);

router.get('/News/detail/:News_id',NewsController.get_news_detail);

router.post('/News/add',NewsController.insert_news);

router.delete('/News/delete/:News_id',NewsController.delete_news);

router.put('/News/update',NewsController.update_news);
} 