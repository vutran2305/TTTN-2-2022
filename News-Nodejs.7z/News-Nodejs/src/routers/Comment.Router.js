module.exports= function(router){
    var CommentController =require('../Controllers/Comment.Controller');

router.get('/Comment/List',CommentController.get_list_Comment);

router.post('/Comment/add',CommentController.insert_Comment);

router.delete('/Comment/delete/:Cmt_id',CommentController.delete_Comment);

router.put('/Comment/update',CommentController.update_Comment);
} 