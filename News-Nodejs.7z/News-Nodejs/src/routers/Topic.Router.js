module.exports= function(router){
    var TopicController =require('../Controllers/Topic.Controller');

router.get('/Topic/List',TopicController.get_list_topic);

router.post('/Topic/add',TopicController.insert_topic);

router.delete('/Topic/delete/:id',TopicController.delete_topic);

router.put('/Topic/update',TopicController.update_topic);
} 