module.exports= function(router){
    var ReplycommentController =require('../Controllers/Replycomment.Controller');

router.get('/Reply_Comment/List',ReplycommentController.get_list_Reply_Comment);

router.post('/Reply_Comment/add',ReplycommentController.Reply_Comment);

router.delete('/Reply_Comment/delete/:Rep_Cmt_id',ReplycommentController.delete_Reply_Comment);

router.put('/Reply_Comment/update',ReplycommentController.update_Reply_Comment);
} 