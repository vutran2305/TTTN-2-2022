var Comment = require ('../services/Comment.Service');
//get
exports.get_list_Comment = function(req,res){
    Comment.get_all(function(data){
        res.send({result:data});
    });
}

//post
//lấy dữ liệu từ form để add
exports.insert_Comment = function (req,res){
    var data = req.body;   
    Comment.create(data,function(respnse){
        res.send({result:respnse});
    });
} 
//delete
exports.delete_Commment = function(req,res){
    var id = req.params.id;
    //callback
    Comment.remove(id,function(respnse){
        res.send({result:respnse});
    })
}
//put (update gioongs add can data)
exports.update_Comment = function(req,res){
    var data = req.body;   
    Comment.update(data,function(respnse){
        res.send({result:respnse});
    });
}  