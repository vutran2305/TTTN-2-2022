const dba = require('../common/Connect');
const News = function(news){
    this.News_Id = news.News_Id;
    this.News_Tiltle = news.News_Tiltle;
    this.News_Content = news.News_Content;
    this.News_View = news.News_View;
    this.News_Cmt= news.News_Cmt;
    this.News_Url = news.News_Url;
    this.News_Img_Upload = news.News_Img_Upload;
    this.Topic_Id = news.Topic_Id;
    this.News_Index = news.News_Index;
    
}
News.get_all = function(result){
   dba.query("SELECT * FROM News1 ",function(err,news){
       if(err){
           result("Error");
       }
       else{
    result(news);
       }
   });

}

News.getById = function(id, result){
    dba.query("SELECT * FROM News1 where News_Id = ?",News_Id,function(err,news){
        if(err || news.length == 0){
            result(null);
        }
        else{
            result(news[0]);
        }
    });
   
}
//post
News.create = function(data,result){

    dba.query("INSERT INTO News1 SET ?",data,function(err,news){
       
        if(err ){
            result(null);
        }
       
        else{
            result({News_Id: news.insertID,...data});
}
    });
}
//delete
News.remove = function(News_Id ,result){
    dba.query("DELETE from News1 WHERE News_Id = ?",News_Id,function(err,news){
        if(err ){
            result(null);
        }
       
        else{
            result("xoá dữ liệu product có id "+ News_Id + " thành công");
}
    });
}

//put (gioongs create)
News.update = function(p,result){
    dba.query("UPDATE News1 SET News_Url =?,News_Tiltle=? ,News_Content =? ,News_View = ?,News_Cmt =?,News_Img_Upload =?,Topic_Id =?,News_Index WHERE News_Id=?",[p.News_Url,p.News_Tiltle,p.News_Content,p.News_View,p.News_Cmt,p.News_Img_Upload,p.Topic_Id,p.News_Index,p.News_Id],function(err,news){
        if(err ){
            result(null);
        }
       
        else{
            
            result(p);
}
    });
}
   
module.exports = News;