var express = require ('express');
var app = express() ;


//cấu hình body-parser
var body_parser = require('body-parser');

require('./app/routes/news.router')(app);



//listen on port 3000 
app.listen(4000,function () {
    console.log("Server listenning on http://localhost:4000");
})